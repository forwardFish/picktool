import React from 'react';
import { Sparkles, Search, Film, FileText, AppWindow, Images, UserRound } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-[#05060f] text-white relative overflow-hidden font-sans selection:bg-purple-500/30">
      
      {/* --- BACKGROUND EFFECTS --- */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden flex flex-col items-center justify-end">
        {/* Starry Background (CSS Pattern) */}
        <div 
          className="absolute inset-0 opacity-[0.25]"
          style={{
            backgroundImage: `
              radial-gradient(1.5px 1.5px at 20px 30px, #ffffff, rgba(0,0,0,0)),
              radial-gradient(1px 1px at 40px 70px, #ffffff, rgba(0,0,0,0)),
              radial-gradient(1px 1px at 50px 160px, #ffffff, rgba(0,0,0,0)),
              radial-gradient(1.5px 1.5px at 90px 40px, #ffffff, rgba(0,0,0,0)),
              radial-gradient(2px 2px at 130px 80px, #ffffff, rgba(0,0,0,0)),
              radial-gradient(1px 1px at 160px 120px, #ffffff, rgba(0,0,0,0)),
              radial-gradient(2px 2px at 200px 200px, #ffffff, rgba(0,0,0,0)),
              radial-gradient(1px 1px at 250px 60px, #ffffff, rgba(0,0,0,0))
            `,
            backgroundSize: '250px 250px',
          }}
        />

        {/* Top Glows */}
        <div className="absolute top-[-20%] right-[-10%] w-[50%] h-[50%] bg-[#4A80F0]/10 blur-[150px] rounded-full mix-blend-screen" />
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[50%] bg-[#8E64FF]/10 blur-[140px] rounded-full mix-blend-screen" />
        
        {/* Center Backdrop Glow */}
        <div className="absolute top-[30%] left-1/2 -translate-x-1/2 w-[80%] h-[40%] bg-[#4A80F0]/5 blur-[120px] rounded-full mix-blend-screen" />

        {/* The Planet/Earth at the bottom */}
        <div className="relative w-[180%] max-w-[2500px] h-[500px] translate-y-[45%] md:translate-y-[40%] lg:translate-y-[35%]">
            {/* The deep core glow */}
            <div className="absolute inset-0 bg-[#4A80F0]/30 blur-[100px] rounded-[100%_100%_0_0/100%_100%_0_0]" />
            
            {/* The sharp surface edge */}
            <div className="absolute inset-0 rounded-[100%_100%_0_0/100%_100%_0_0] shadow-[0_-15px_80px_rgba(74,128,240,0.5)] border-t border-[#4A80F0]/50 z-10" />
            <div className="absolute inset-0 rounded-[100%_100%_0_0/100%_100%_0_0] shadow-[0_-2px_10px_rgba(255,255,255,0.4)] border-t border-white/30 z-20 mix-blend-overlay" />
            
            {/* The surface texture/fill */}
            <div 
              className="absolute inset-0 rounded-[100%_100%_0_0/100%_100%_0_0] overflow-hidden"
              style={{
                background: 'radial-gradient(ellipse at top, #020617 0%, #000000 70%)'
              }}
            >
              {/* City lights simulation on planet */}
              <div 
                className="absolute inset-0 opacity-[0.9] mix-blend-screen"
                style={{
                  backgroundImage: `
                    radial-gradient(1px 1px at 10% 15%, #facc15, rgba(0,0,0,0)),
                    radial-gradient(1.5px 1.5px at 20% 10%, #fef08a, rgba(0,0,0,0)),
                    radial-gradient(1px 1px at 25% 25%, #fbbf24, rgba(0,0,0,0)),
                    radial-gradient(2px 1.5px at 35% 8%, #facc15, rgba(0,0,0,0)),
                    radial-gradient(1px 1px at 45% 20%, #fef08a, rgba(0,0,0,0)),
                    radial-gradient(1.5px 1px at 55% 12%, #fbbf24, rgba(0,0,0,0)),
                    radial-gradient(1px 1px at 65% 18%, #facc15, rgba(0,0,0,0)),
                    radial-gradient(2px 2px at 75% 10%, #fef08a, rgba(0,0,0,0)),
                    radial-gradient(1.5px 1.5px at 85% 22%, #fbbf24, rgba(0,0,0,0)),
                    radial-gradient(1px 1px at 95% 15%, #facc15, rgba(0,0,0,0))
                  `,
                  backgroundSize: '200px 60px',
                  backgroundRepeat: 'repeat-x'
                }}
              />
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-[80px] bg-white/10 blur-[30px] mix-blend-screen" />
            </div>
        </div>
      </div>

      {/* --- CONTENT --- */}
      <div className="relative z-10 flex flex-col min-h-screen">
        
        {/* Header */}
        <header className="flex items-center justify-between px-6 py-6 md:px-12 w-full max-w-7xl mx-auto">
          <div className="flex items-center gap-3 cursor-pointer group">
            <div className="relative flex items-center justify-center w-8 h-8">
               <div className="absolute inset-0 bg-[#4A80F0] blur-lg opacity-40 rounded-full group-hover:opacity-70 transition-opacity" />
               <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 relative z-10">
                 <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" fill="url(#paint0_linear_logo)" />
                 <defs>
                    <linearGradient id="paint0_linear_logo" x1="2" y1="2" x2="22" y2="22" gradientUnits="userSpaceOnUse">
                      <stop stopColor="#4A80F0" />
                      <stop offset="1" stopColor="#D55AF2" />
                    </linearGradient>
                 </defs>
               </svg>
            </div>
            <span className="text-[17px] font-semibold tracking-wide text-white">AI Tool Decision Assistant</span>
          </div>
          <button className="px-5 py-2 text-[15px] font-medium border border-gray-700/80 rounded-xl hover:bg-white/10 hover:border-gray-500 transition-all text-white bg-transparent backdrop-blur-sm">
            Log in
          </button>
        </header>

        {/* Hero Section */}
        <main className="flex-1 flex flex-col items-center pt-20 pb-32 px-4">
          
          {/* Main Typography */}
          <div className="text-center max-w-4xl mx-auto flex flex-col items-center mb-8 font-bold leading-[1.1] tracking-[-0.02em]">
            <h1 className="text-[52px] sm:text-[64px] lg:text-[84px] text-white drop-shadow-sm">
              Make better
            </h1>
            <div className="flex justify-center w-full">
               <h1 className="text-[52px] sm:text-[64px] lg:text-[84px] bg-gradient-to-r from-[#4A80F0] via-[#8E64FF] to-[#D55AF2] bg-clip-text text-transparent drop-shadow-[0_0_20px_rgba(142,100,255,0.4)] pb-2 relative">
                 AI tool decisions
               </h1>
            </div>
            <h1 className="text-[52px] sm:text-[64px] lg:text-[84px] text-white flex items-baseline justify-center drop-shadow-sm">
              for every task<span className="text-[#D55AF2] ml-[-2px]">.</span>
            </h1>
          </div>

          <p className="text-[#A1A1AA] text-[17px] md:text-[19px] text-center max-w-[650px] mb-12 font-medium leading-[1.6]">
            Describe what you want to do. We'll show which<br className="hidden md:block" />
            AI tools to use, which to skip, and how to get started.
          </p>

          {/* Search Bar - Glow & Input */}
          <div className="w-full max-w-[800px] relative group mt-2">
            {/* Outer Luminous Glow Rings */}
            <div className="absolute -inset-[3px] bg-gradient-to-r from-[#4A80F0]/60 via-[#8E64FF]/60 to-[#4A80F0]/60 rounded-[30px] blur-[12px] opacity-70 group-hover:opacity-100 transition duration-500" />
            <div className="absolute -inset-[1px] bg-gradient-to-r from-[#4A80F0] via-[#D55AF2] to-[#4A80F0] rounded-[28px] opacity-50 blur-[2px]" />
            
            {/* The sharp inner border & Background */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#4A80F0] via-[#D55AF2] to-[#4A80F0] rounded-[26px] p-[1.5px]">
               <div className="absolute inset-[1.5px] bg-[#070918] rounded-[24px] z-0" />
            </div>

            {/* Content of Search Bar */}
            <div className="relative z-10 flex flex-col sm:flex-row items-center p-2 rounded-[26px]">
              <div className="pl-5 pr-3 py-3 hidden sm:block">
                <Search className="w-[22px] h-[22px] text-gray-400" />
              </div>
              <input 
                type="text" 
                placeholder="I want to create a product promo video for TikTok."
                className="flex-1 w-full bg-transparent border-none outline-none text-white text-[17px] placeholder-[#6b7280] px-5 py-4 sm:py-0 sm:px-2 font-medium"
              />
              <button className="w-full sm:w-auto mt-2 sm:mt-0 bg-gradient-to-r from-[#4A80F0] to-[#8E64FF] hover:from-[#3b6ee0] hover:to-[#7d53ef] px-7 py-[14px] rounded-[18px] text-[16px] font-semibold flex items-center justify-center gap-2 transition-all shadow-[0_0_20px_rgba(142,100,255,0.4)] hover:shadow-[0_0_25px_rgba(142,100,255,0.6)] text-white group/btn">
                <Sparkles className="w-5 h-5 text-white group-hover/btn:rotate-12 transition-transform" />
                <span>Get Decision</span>
              </button>
            </div>
          </div>

          {/* Suggestion Pills */}
          <div className="flex flex-wrap items-center justify-center gap-[14px] mt-14 max-w-4xl px-2">
            <SuggestionPill 
              icon={<Film className="w-[18px] h-[18px]" strokeWidth={2} />} 
              label="Product video" 
              color="text-[#8E64FF]"
            />
            <SuggestionPill 
              icon={<FileText className="w-[18px] h-[18px]" strokeWidth={2} />} 
              label="PDF to slides" 
              color="text-[#4A80F0]"
            />
            <SuggestionPill 
              icon={<AppWindow className="w-[18px] h-[18px]" strokeWidth={2} />} 
              label="Landing page" 
              color="text-[#4A80F0]"
            />
            <SuggestionPill 
              icon={<Images className="w-[18px] h-[18px]" strokeWidth={2} />} 
              label="Instagram carousel" 
              color="text-[#8E64FF]"
            />
            <SuggestionPill 
              icon={<UserRound className="w-[18px] h-[18px]" strokeWidth={2} />} 
              label="AI avatar video" 
              color="text-[#D55AF2]"
            />
          </div>

        </main>
      </div>
    </div>
  );
}

function SuggestionPill({ icon, label, color }: { icon: React.ReactNode, label: string, color: string }) {
  return (
    <button className="flex items-center gap-[10px] px-5 py-[10px] rounded-[20px] border border-[#2d3154]/60 bg-[#12142B]/50 hover:bg-[#1C1F3E]/80 hover:border-[#4A80F0]/50 transition-all duration-300 text-[14.5px] font-medium text-[#D1D5DB] group shadow-[0_4px_15px_rgba(0,0,0,0.2)] hover:shadow-[0_0_15px_rgba(74,128,240,0.15)] backdrop-blur-sm">
      <span className={`${color} group-hover:scale-110 transition-transform duration-300 drop-shadow-sm`}>{icon}</span>
      {label}
    </button>
  );
}